/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facture;

/**
 *
 * @author Raboss
 */
public class facture {
    private int NumCli;
    private int IdOrdi;
    private int Quantite;
    
    public int getNumCli(){
        return NumCli;
    }
    public int getIdOrdi(){
        return IdOrdi;
    }
    public int getQuantite(){
        return Quantite;
    }
    
    public void setNumCli(int NumCli){
        this.NumCli = NumCli;
    }
    public void setIdOrdi(int IdOrdi){
        this.IdOrdi = IdOrdi;
    }
    public void setQuantite(int Quantite){
        this.Quantite = Quantite;
    }
}
