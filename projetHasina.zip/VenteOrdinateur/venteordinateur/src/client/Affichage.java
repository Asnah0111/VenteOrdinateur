package client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Affichage {
    PreparedStatement st = null;
    ResultSet rs = null;
    Connection con = null;
    

    public ArrayList<Client> afficher() {

        ArrayList list = new ArrayList<Client>();
        con = Connexion.getCon();

        String select = "SELECT * FROM client";
        try {
            st = con.prepareStatement(select);
            rs = st.executeQuery();
            while (rs.next()) {
                Client cli = new Client();
                cli.setNumCli(rs.getInt("NumCli"));
                cli.setNomCli(rs.getString("NomCli"));
                cli.setPrenomCli(rs.getString("PrenomCli"));
                cli.setAdresseCli(rs.getString("AdresseCli"));

                list.add(cli);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Affichage.class.getName()).log(Level.SEVERE, null, ex);
        }

        return list;
    }
    
    public ArrayList<Client> Find(int n) {

        ArrayList list = new ArrayList<Client>();
        con = Connexion.getCon();

        String select = "SELECT * FROM client WHERE NumCli='"+n+"'";
        try {
            st = con.prepareStatement(select);
            rs = st.executeQuery();
            while (rs.next()) {
                Client cli = new Client();
                cli.setNumCli(rs.getInt("NumCli"));
                cli.setNomCli(rs.getString("NomCli"));
                cli.setPrenomCli(rs.getString("PrenomCli"));
                cli.setAdresseCli(rs.getString("AdresseCli"));

                list.add(cli);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Affichage.class.getName()).log(Level.SEVERE, null, ex);
        }

        return list;
    }
}
