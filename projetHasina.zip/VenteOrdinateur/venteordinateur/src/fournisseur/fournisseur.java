/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fournisseur;

/**
 *
 * @author Hasina
 */
public class fournisseur {
     private int NumFrns;
    private String NomFrns;
    private String AdrFrns;
    
    public fournisseur() {
    }
    
    public int getNumFrns(){
        return NumFrns;
    }
    public String getNomFrns(){
        return NomFrns;
    }
    public String getAdrFrns(){
        return AdrFrns;
    }
    
    
    public void setNumFrns(int NumFrns) {
        this.NumFrns = NumFrns;
    }
    public void setNomFrns(String NomFrns) {
        this.NomFrns = NomFrns;
    }
    public void setAdrFrns(String AdrFrns) {
        this.AdrFrns = AdrFrns;
    }
}
