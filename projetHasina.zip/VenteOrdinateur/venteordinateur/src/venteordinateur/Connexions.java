/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package venteordinateur;

/**
 *
 * @author hasina
 */
import client.*;
import java.sql.*;
import javax.swing.JOptionPane;
public class Connexions {
    static String url = "jdbc:mysql://localhost/venteordinateur";
    static String driver = "com.mysql.jdbc.Driver";
    static String user = "root";
    static String password = "";
    public static Connection getCon() {
        Connection con = null;
        //String message="Probleme de connection";
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, user, password);

        } catch (ClassNotFoundException | SQLException e) {
            String message = e.getMessage();
            JOptionPane.showMessageDialog(null,"Erreur"+ message);

        }
        return con;
    }
}
