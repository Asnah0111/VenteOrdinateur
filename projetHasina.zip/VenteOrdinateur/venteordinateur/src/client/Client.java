/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

/**
 *
 * @author Raboss
 */
public class Client {
    private int NumCli;
    private String NomCli;
    private String PrenomCli;
    private String AdresseCli;
    
    public Client() {
    }
    
    public int getNumCli(){
        return NumCli;
    }
    public String getNomCli(){
        return NomCli;
    }
    public String getPrenomCli(){
        return PrenomCli;
    } 
    public String getAdresseCli(){
        return AdresseCli;
    }
    
    
    public void setNumCli(int NumCli) {
        this.NumCli = NumCli;
    }
    public void setNomCli(String NomCli) {
        this.NomCli = NomCli;
    }
    public void setPrenomCli(String PrenomCli) {
        this.PrenomCli = PrenomCli;
    }
    public void setAdresseCli(String AdresseCli) {
        this.AdresseCli = AdresseCli;
    }
}
