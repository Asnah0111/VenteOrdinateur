/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package venteordinateur;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Raboss
 */
public class connexion {
    String urlp = "com.mysql.jdbc.Driver";
    String url = "jdbc:mysql://localhost/venteordinateur";
    String user = "root";
    String pwd = "";
    Connection con;
    
    public connexion() {
        //Chargement de notre pilote
        try {
            Class.forName(urlp);
            System.out.println("Pilote marche");
        } catch (ClassNotFoundException e) {
            System.out.println("Erreur lors du chargement du pilote !");
        }
        
        //Connexion a la base de donne
        try {
            con = DriverManager.getConnection(url, user, pwd);
            System.out.println("Connection success");
        } catch (SQLException e) {
            System.out.println(e);
        }
        
    }
    
    public Connection ObtenirConnexion() {
        return con;
        }
    
}
