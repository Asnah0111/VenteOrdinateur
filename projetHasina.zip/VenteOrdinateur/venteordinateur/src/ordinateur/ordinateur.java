/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordinateur;

/**
 *
 * @author Raboss
 */
public class ordinateur {
    private int IdOrdi;
    private String Marque;
    private int Ram;
    private int Prix;
    
    public ordinateur() {
    }
    
    public int getIdOrdi(){
        return IdOrdi;
    }
    public String getMarque(){
        return Marque;
    }
    public int getRam(){
        return Ram;
    } 
    public int getPrix(){
        return Prix;
    }
    
    
    public void setIdOrdi(int IdOrdi) {
        this.IdOrdi = IdOrdi;
    }
    public void setMarque(String Marque) {
        this.Marque = Marque;
    }
    public void setRam(int Ram) {
        this.Ram = Ram;
    }
    public void setPrix(int Prix) {
        this.Prix = Prix;
    }
}

