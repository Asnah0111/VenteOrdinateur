/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Facture;

import Acheter.*;
import client.Connexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Raboss
 */
public class Affichage {
    PreparedStatement st = null;
    ResultSet rs = null;
    Connection con = null;
    

    public ArrayList<facture> afficher() {

        ArrayList list = new ArrayList<facture>();
        con = Connexion.getCon();

        String select = "SELECT * FROM acheter";
        try {
            st = con.prepareStatement(select);
            rs = st.executeQuery();
            while (rs.next()) {
                facture ordi = new facture();
                ordi.setIdOrdi(rs.getInt("IdOrdi"));
                ordi.setNumCli(rs.getInt("NumCli"));
                ordi.setQuantite(rs.getInt("Quantite"));
                
                list.add(ordi);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Affichage.class.getName()).log(Level.SEVERE, null, ex);
        }

        return list;
    }
    
}
