/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fournisseur;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import venteordinateur.Connexions;

/**
 *
 * @author Raboss
 */
public class Affichage {
    PreparedStatement st = null;
    ResultSet rs = null;
    Connection con = null;
    

    public ArrayList<fournisseur> afficher() {

        ArrayList list = new ArrayList<fournisseur>();
        con = Connexions.getCon();

        String select = "SELECT * FROM fournisseur";
        try {
            st = con.prepareStatement(select);
            rs = st.executeQuery();
            while (rs.next()) {
                fournisseur four = new fournisseur();
                four.setNumFrns(rs.getInt("NumFrns"));
                four.setNomFrns(rs.getString("NomFrns"));
                four.setAdrFrns(rs.getString("AdrFrns"));

                list.add(four);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Affichage.class.getName()).log(Level.SEVERE, null, ex);
        }

        return list;
    }
}


