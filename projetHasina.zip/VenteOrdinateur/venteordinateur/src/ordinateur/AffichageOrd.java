/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordinateur;

import fournisseur.fournisseur;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import venteordinateur.Connexions;

/**
 *
 * @author Raboss
 */
public class AffichageOrd {
     PreparedStatement st = null;
    ResultSet rs = null;
    Connection con = null;
    

    public ArrayList<ordinateur> afficher() {

        ArrayList list = new ArrayList<fournisseur>();
        con = Connexions.getCon();

        String select = "SELECT * FROM ordinateur";
        try {
            st = con.prepareStatement(select);
            rs = st.executeQuery();
            while (rs.next()) {
                ordinateur ordi = new ordinateur();
                ordi.setIdOrdi(rs.getInt("IdOrdi"));
                ordi.setMarque(rs.getString("Marque"));
                ordi.setRam(rs.getInt("Ram"));
                ordi.setPrix(rs.getInt("Prix"));

                list.add(ordi);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AffichageOrd.class.getName()).log(Level.SEVERE, null, ex);
        }

        return list;
    }
    
    public ArrayList<ordinateur> tadiavina(int n) {

        ArrayList list = new ArrayList<fournisseur>();
        con = Connexions.getCon();

        String select = "SELECT * FROM ordinateur WHERE IdOrdi='"+n+"'";
        try {
            st = con.prepareStatement(select);
            rs = st.executeQuery();
            while (rs.next()) {
                ordinateur ordi = new ordinateur();
                ordi.setIdOrdi(rs.getInt("IdOrdi"));
                ordi.setMarque(rs.getString("Marque"));
                ordi.setRam(rs.getInt("Ram"));
                ordi.setPrix(rs.getInt("Prix"));

                list.add(ordi);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AffichageOrd.class.getName()).log(Level.SEVERE, null, ex);
        }

        return list;
    }
}


