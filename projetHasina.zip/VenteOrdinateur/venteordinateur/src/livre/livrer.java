/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package livre;

/**
 *
 * @author Raboss
 */
public class livrer {
    private int IdOrdi;
    private int NumFrns;
    private int QteLiv;
    private int Montant;
    
    public livrer(){
    }
    public int getIdOrdi(){
        return IdOrdi;
    }
    public int getNumFrns(){
        return NumFrns;
    }
    public int getQteLiv(){
        return QteLiv;
    }
    public int getMontant(){
        return Montant;
    }
    
    
    public void setIdOrdi(int IdOrdi) {
        this.IdOrdi = IdOrdi;
    }
    public void setNumFrns(int NumFrns) {
        this.NumFrns = NumFrns;
    }
    public void setQteLiv(int QteLiv) {
        this.QteLiv = QteLiv;
    }
    public void setMontant(int Montant) {
        this.Montant = Montant;
    }
    
    
}
